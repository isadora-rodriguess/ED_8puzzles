#ifndef SOLVER_H
#define SOLVER_H

#include "tabuleiro.h"

typedef struct {
    int minimoMovimentos;
} Buscador;

void calcularSolucaoOtima(Buscador *busc, Tabuleiro configuracaoInicial);

int obterNumeroMinimoDeMovimentos(const Buscador *busc);

#endif
