#ifndef PILHA_H
#define PILHA_H
 
#include "tabuleiro.h"   // de onde vem o tipo Movimento
 
#define MAX_PILHA 10000  // máximo de movimentos guardados no histórico
 
/* Pilha implementada para guardar os movimentos do jogador para o Undo. */
typedef struct {
    Movimento dados[MAX_PILHA];  // movimentos guardados, do fundo até o topo
    int topo;                    
} Pilha;
 
void pilha_inicializar(Pilha *p);
int pilha_vazia(const Pilha *p);
int pilha_cheia(const Pilha *p);
int pilha_empilhar(Pilha *p, Movimento movimento);
int pilha_desempilhar(Pilha *p, Movimento *movimento);
int pilha_topo(const Pilha *p, Movimento *movimento);
 
#endif
