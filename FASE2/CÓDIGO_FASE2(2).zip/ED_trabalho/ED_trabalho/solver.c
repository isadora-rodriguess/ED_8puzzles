

#include <stdlib.h>
#include "solver.h"
#include "fila.h"

#define TOTAL_ESTADOS 362880

static int indiceDoEstado(const Tabuleiro *tab) {
    int seq[TAM * TAM];
    int n = 0;

    for (int l = 0; l < TAM; l++)
        for (int c = 0; c < TAM; c++)
            seq[n++] = tab->celulas[l][c];

    int indice = 0;

    for (int i = 0; i < n; i++) {
        int menores = 0;

        for (int j = i + 1; j < n; j++)
            if (seq[j] < seq[i])
                menores++;

        indice = indice * (n - i) + menores;
    }

    return indice;
}

void calcularSolucaoOtima(Buscador *busc, Tabuleiro configuracaoInicial) {
    static const int dl[4] = {-1, 1, 0, 0};
    static const int dc[4] = {0, 0, -1, 1};

    busc->minimoMovimentos = -1;

    if (!configuracaoEhSolucionavel(configuracaoInicial.celulas))
        return;

    unsigned char *visitado = calloc(TOTAL_ESTADOS, sizeof(unsigned char));
    Fila *fila = malloc(sizeof(Fila));

    if (!visitado || !fila) {
        free(visitado);
        free(fila);
        return;
    }

    fila_inicializar(fila);

    EstadoBusca atual = {configuracaoInicial, 0};

    visitado[indiceDoEstado(&atual.tabuleiro)] = 1;

    if (!fila_enfileirar(fila, atual)) {
        free(visitado);
        free(fila);
        return;
    }

    while (fila_desenfileirar(fila, &atual)) {
        if (estaResolvido(&atual.tabuleiro)) {
            busc->minimoMovimentos = atual.movimentos;
            break;
        }

        Posicao vazio = encontrarVazio(&atual.tabuleiro);

        for (int d = 0; d < 4; d++) {
            Posicao pos = {
                vazio.linha + dl[d],
                vazio.coluna + dc[d]
            };

            EstadoBusca proximo = {
                atual.tabuleiro,
                atual.movimentos + 1
            };

            if (!moverPeca(&proximo.tabuleiro, pos))
                continue;

            int indice = indiceDoEstado(&proximo.tabuleiro);

            if (visitado[indice])
                continue;

            visitado[indice] = 1;

            if (!fila_enfileirar(fila, proximo)) {
                free(visitado);
                free(fila);
                return;
            }
        }
    }

    free(visitado);
    free(fila);
}

int obterNumeroMinimoDeMovimentos(const Buscador *busc) {
    return busc->minimoMovimentos;
}
