#include <string.h>
#include "ranking.h"
 
 
/* Implementação da estrutura de dados Lista */
 
/* Cria uma lista vazia. */
Lista lista_inicializar(void) {
    Lista l;
    l.quantidade = 0;
 
    return l;
}
 
/* Retorna 1 se a lista chegou à capacidade máxima (MAX_LISTA). */
int lista_cheia(const Lista *l) {
    return l->quantidade == MAX_LISTA;
}
 
/* Retorna 1 se a lista não tem nenhum resultado. */
int lista_vazia(const Lista *l) {
    return l->quantidade == 0;
}
 
/* Insere o resultado na primeira posição livre (o fim da lista).
   Retorna 1 se inseriu e 0 se a lista estava cheia. */
int lista_inserir_fim(Lista *l, Resultado resultado) {
    if (lista_cheia(l)) {
        return 0;
    }
 
    l->vetor[l->quantidade] = resultado;
    l->quantidade++;
 
    return 1;
}
 
/* Remove o resultado da posição indicada. Retorna 1 se removeu e 0 se a posição
   for inválida ou a lista estiver vazia. */
int lista_remover(Lista *l, int posicao) {
    if (lista_vazia(l) || posicao < 0 || posicao >= l->quantidade) {
        return 0;
    }
 
    for (int i = posicao; i < l->quantidade - 1; i++) {
        l->vetor[i] = l->vetor[i + 1];
    }
 
    l->quantidade--;
 
    return 1;
}
 
 
/* Implementação do TAD Ranking */
 
/* Cria um ranking vazio. */
void inicializarRanking(Ranking *rank) {
    rank->resultados = lista_inicializar();
}
 
/* Converte o jogador em um Resultado (nome, movimentos e tempo) e o insere na
   lista. Retorna 1 se inseriu e 0 se a lista estava cheia. */
int inserirResultado(Ranking *rank, Jogador jog) {
    Resultado res;
 
    // cópia segura do nome, sempre terminando em '\0'
    strncpy(res.nome, jog.nome, TAM_NOME - 1);
    res.nome[TAM_NOME - 1] = '\0';
 
    res.movimentos = obterMovimentos(&jog);
    res.tempo = (float)obterTempoDecorrido(&jog);
 
    return lista_inserir_fim(&rank->resultados, res);
}
 
/* Critério de classificação: retorna 1 se "a" deve vir antes de "b".
   Menos movimentos vem primeiro; em empate, o menor tempo. */
static int vemAntes(Resultado a, Resultado b) {
    if (a.movimentos != b.movimentos) {
        return a.movimentos < b.movimentos;
    }
 
    return a.tempo <= b.tempo;
}
 
/* Utilizamos o merge para fazer a ordenação 
e garantir que será feita no menor tempo possível */
static void merge(Resultado vetor[], int inicio, int meio, int fim) {
    int i = inicio;      
    int j = meio + 1;    
    int k = 0;           
 
    Resultado aux[MAX_LISTA];
 
    while (i <= meio && j <= fim) {
        if (vemAntes(vetor[i], vetor[j])) {
            aux[k++] = vetor[i++];
        } else {
            aux[k++] = vetor[j++];
        }
    }
 
    while (i <= meio) {          
        aux[k++] = vetor[i++];
    }
 
    while (j <= fim) {           
        aux[k++] = vetor[j++];
    }
 
    for (k = 0; k < fim - inicio + 1; k++) {
        vetor[inicio + k] = aux[k];
    }
}
 
static void mergeSort(Resultado vetor[], int inicio, int fim) {
    if (inicio < fim) {
        int meio = inicio + (fim - inicio) / 2;
 
        mergeSort(vetor, inicio, meio);
        mergeSort(vetor, meio + 1, fim);
 
        merge(vetor, inicio, meio, fim);
    }
}
 
/* Ordena o ranking por movimentos (crescente) e, em empate, por tempo. */
void ordenarPorMovimentosETempo(Ranking *rank) {
    if (rank->resultados.quantidade > 1) {
        mergeSort(rank->resultados.vetor, 0,
                  rank->resultados.quantidade - 1);
    }
}
 
/* Copia os resultados do ranking para o vetor 'saida' e retorna quantos foram
   copiados. */
int obterClassificacaoFinal(const Ranking *rank, Resultado saida[]) {
    int quantidade = rank->resultados.quantidade;
 
    for (int i = 0; i < quantidade; i++) {
        saida[i] = rank->resultados.vetor[i];
    }
 
    return quantidade;
}