#include <stdio.h>
#include "tabuleiro.h"
#include "solver.h"
#include "jogo.h"
#include "ranking.h"

//Contadores para acompanhar os resultados dos testes.
int testesPassaram = 0;
int testesFalharam = 0;

// Exibe o resultado de cada teste e atualiza os contadores.
void resultadoTeste(const char *descricao, int passou) {
   
    if (passou) {
        printf("[PASSOU] %s\n", descricao);
        testesPassaram++;
    } else {
        printf("[FALHOU] %s\n", descricao);
        testesFalharam++;
    }
    
}

int main(void) {

    /* Configuração inicial: são necessários apenas dois movimentos
       para chegar à configuração final do puzzle.

       1 2 3
       4 5 6
       0 7 8
    */
    int configuracaoInicial[TAM][TAM] = {
        {1, 2, 3},
        {4, 5, 6},
        {0, 7, 8}
    };

    //Configuração impossível: a troca entre 1 e 2 produz um número ímpar de inversões.
    int configuracaoImpossivel[TAM][TAM] = {
        {2, 1, 3},
        {4, 5, 6},
        {7, 8, 0}
    };

    Tabuleiro tabuleiroInicial;
    inicializar(&tabuleiroInicial, configuracaoInicial);

    
    // TESTE 1 - VALIDAÇÃO DO TABULEIRO

    // Verifica se uma configuração válida é reconhecida como solucionável.
    resultadoTeste("Configuracao inicial solucionavel", configuracaoEhSolucionavel(configuracaoInicial));

    // Verifica se uma configuração com paridade incorreta é corretamente rejeitada.
    resultadoTeste("Configuracao impossivel rejeitada", !configuracaoEhSolucionavel(configuracaoImpossivel));


    // TESTE 2 - SOLVER E BENCHMARK

    Buscador buscador;

    // O Solver utiliza BFS para encontrar o menor número de movimentos entre a configuração inicial e a final.
    calcularSolucaoOtima(&buscador, tabuleiroInicial);

    resultadoTeste("Solver encontra a solucao minima de 2 movimentos", obterNumeroMinimoDeMovimentos(&buscador) == 2);

    printf("Benchmark calculado: %d movimentos\n", obterNumeroMinimoDeMovimentos(&buscador));

    
    // TESTE 3 - INICIALIZAÇÃO DA PARTIDA

    Partida partida;
    Jogador jogador = inicializar_jogador();

    definirNome(&jogador, "Jogador Teste");
    iniciarPartida(&partida, tabuleiroInicial);
    iniciarCronometro(&jogador);

    // Guarda na partida o benchmark calculado pelo Solver.
    definirBenchmark(&partida, obterNumeroMinimoDeMovimentos(&buscador));

    // Verifica se o tabuleiro atual começa igual ao inicial.
    resultadoTeste("Tabuleiro atual igual a configuracao inicial", tabuleirosIguais(&partida.tabuleiroAtual, &tabuleiroInicial));

    // Verifica se o histórico começa vazio.
    resultadoTeste("Historico inicial vazio", pilha_vazia(&partida.historico));

    // O status 1 indica que a partida está em andamento.
    resultadoTeste("Partida iniciada corretamente", partida.status == 1);

    // Verifica se o benchmark foi armazenado corretamente.
    resultadoTeste("Benchmark armazenado na partida", obterBenchmark(&partida) == 2);


    // TESTE 4 - MOVIMENTO VÁLIDO

    Movimento movimento;

    movimento.peca = 7;
    movimento.origem.linha = 2;
    movimento.origem.coluna = 1;
    movimento.destino.linha = 2;
    movimento.destino.coluna = 0;

    // Move a peça 7 para o espaço vazio. Verifica se o movimento é registrado corretamente.
    int movimentoRegistrado = registrarMovimentoDoJogador(&partida, &jogador, movimento);

    resultadoTeste("Movimento valido registrado", movimentoRegistrado);

    // Um movimento válido deve incrementar o contador.
    resultadoTeste("Contador atualizado para 1", obterMovimentos(&jogador) == 1);

    // Verifica se o movimento foi guardado na Pilha.
    resultadoTeste("Movimento guardado no historico", !pilha_vazia(&partida.historico));

    printf("\nTabuleiro apos o movimento:\n"); imprimirTabuleiro(&partida.tabuleiroAtual);


     //  TESTE 5 - MOVIMENTO INVÁLIDO

    // Guarda uma cópia do tabuleiro para comparar o estado antes e depois da tentativa inválida.
    Tabuleiro estadoAntesMovimentoInvalido = obterEstadoAtual(&partida.tabuleiroAtual);

    Movimento movimentoInvalido;

    movimentoInvalido.peca = 1;
    movimentoInvalido.origem.linha = 0;
    movimentoInvalido.origem.coluna = 0;

    // Esta posição não é adjacente ao espaço vazio.
    movimentoInvalido.destino.linha = 2;
    movimentoInvalido.destino.coluna = 1;

    resultadoTeste("Movimento nao adjacente rejeitado", !registrarMovimentoDoJogador( &partida, &jogador, movimentoInvalido));

    // Um movimento inválido não deve alterar o tabuleiro.
    resultadoTeste("Tabuleiro permanece inalterado", tabuleirosIguais( &partida.tabuleiroAtual, &estadoAntesMovimentoInvalido));

    // O contador também não deve ser incrementado.
    resultadoTeste("Contador permanece em 1", obterMovimentos(&jogador) == 1);


    // TESTE 6 - UNDO NORMAL

    // Desfaz o último movimento e verifica se o tabuleiro retorna exatamente à configuração inicial.
    int undoRealizado = desfazerMovimento(&partida, &jogador);

    resultadoTeste("Undo realizado com sucesso", undoRealizado);

    resultadoTeste("Tabuleiro restaurado corretamente", tabuleirosIguais(&partida.tabuleiroAtual, &tabuleiroInicial));

    // Depois do undo, não deve restar nenhum movimento no histórico.
    resultadoTeste("Historico vazio apos o undo", pilha_vazia(&partida.historico));

    // O undo também conta como um movimento do jogador.
    resultadoTeste("Contador inclui o movimento desfeito", obterMovimentos(&jogador) == 2);


    //  TESTE 7 - UNDO COM ESTADO INCONSISTENTE

    Partida partidaInconsistente;
    Jogador jogadorInconsistente = inicializar_jogador();

    definirNome(&jogadorInconsistente, "Teste Undo");

    iniciarPartida(&partidaInconsistente, tabuleiroInicial);

    // Primeiro, registra um movimento válido para que exista um elemento no histórico.
    registrarMovimentoDoJogador(&partidaInconsistente, &jogadorInconsistente, movimento);

    // Agora simulamos uma inconsistência no tabuleiro: o espaço vazio fica longe da posição onde a peça deveria voltar durante o undo.
    
    // Assim, moverPeca() não conseguirá restaurar o movimento.
    int configuracaoInconsistente[TAM][TAM] = {
        {0, 2, 3},
        {1, 5, 6},
        {4, 7, 8}
    };

    inicializar(&partidaInconsistente.tabuleiroAtual, configuracaoInconsistente);

    Tabuleiro estadoAntesUndoFalho = obterEstadoAtual(&partidaInconsistente.tabuleiroAtual);

    // Tentamos desfazer o movimento mesmo com o estado inconsistente.
    int undoInconsistente = desfazerMovimento(&partidaInconsistente, &jogadorInconsistente);

    // O comportamento esperado seria informar que o undo falhou.
    resultadoTeste("Undo inconsistente informa falha", !undoInconsistente);

    // Se a restauração falhar, o movimento deveria continuar guardado na Pilha, permitindo uma nova tentativa.
    resultadoTeste("Historico preservado apos falha no undo", !pilha_vazia(&partidaInconsistente.historico));

    // Uma operação de undo que falhou não deveria incrementar o contador de movimentos.
    resultadoTeste("Contador nao muda quando o undo falha", obterMovimentos(&jogadorInconsistente) == 1);

    // A tentativa de undo também não deveria alterar o tabuleiro quando não consegue restaurar o movimento.
    resultadoTeste("Tabuleiro permanece inalterado", tabuleirosIguais(&partidaInconsistente.tabuleiroAtual, &estadoAntesUndoFalho));

    //   TESTE 8 - VERIFICAÇÃO DE VITÓRIA

    Partida partidaVitoria;
    Jogador jogadorVitoria = inicializar_jogador();

    definirNome(&jogadorVitoria, "Jogador Vencedor");

    iniciarPartida(&partidaVitoria, tabuleiroInicial);
    iniciarCronometro(&jogadorVitoria);

    // Primeiro movimento: peça 7 vai para a posição do vazio.
    registrarMovimentoDoJogador(&partidaVitoria, &jogadorVitoria, movimento);

    // Segundo movimento: peça 8 completa a configuração final.
    Movimento ultimoMovimento;

    ultimoMovimento.peca = 8;
    ultimoMovimento.origem.linha = 2;
    ultimoMovimento.origem.coluna = 2;
    ultimoMovimento.destino.linha = 2;
    ultimoMovimento.destino.coluna = 1;

    int ultimoMovimentoRegistrado = registrarMovimentoDoJogador(&partidaVitoria, &jogadorVitoria, ultimoMovimento);

    resultadoTeste("Movimento final registrado", ultimoMovimentoRegistrado);

    // Verifica se o módulo reconhece a configuração final.
    resultadoTeste("Vitoria reconhecida", verificarVitoria(&partidaVitoria));

    // O status deve passar para 0 depois da vitória.
    resultadoTeste("Partida encerrada apos a vitoria", partidaVitoria.status == 0);

    resultadoTeste("Jogador venceu com 2 movimentos", obterMovimentos(&jogadorVitoria) == 2);

    // Documenta o comportamento atual: depois da vitória, o status da partida impede a execução do undo.
    resultadoTeste("Undo apos a vitoria bloqueado", !desfazerMovimento(&partidaVitoria, &jogadorVitoria));

      // TESTE 9 - LISTA E RANKING

    Ranking ranking;
    inicializarRanking(&ranking);

    Jogador jogadorA = inicializar_jogador();
    Jogador jogadorB = inicializar_jogador();
    Jogador jogadorC = inicializar_jogador();

    definirNome(&jogadorA, "Ana");
    definirNome(&jogadorB, "Bruno");
    definirNome(&jogadorC, "Carla");

    // Definimos valores controlados para testar a ordenação sem depender do tempo real de execução.

      // Ana: 4 movimentos, 10 segundos.
      // Bruno: 3 movimentos, 20 segundos.
      // Carla: 3 movimentos, 5 segundos.
    
    jogadorA.movimentos = 4;
    jogadorA.inicio_cronometro = 100;
    jogadorA.fim_cronometro = 110;

    jogadorB.movimentos = 3;
    jogadorB.inicio_cronometro = 100;
    jogadorB.fim_cronometro = 120;

    jogadorC.movimentos = 3;
    jogadorC.inicio_cronometro = 100;
    jogadorC.fim_cronometro = 105;

    // Verifica se os resultados são inseridos na lista.
    resultadoTeste("Ranking aceita Ana", inserirResultado(&ranking, jogadorA));

    resultadoTeste("Ranking aceita Bruno", inserirResultado(&ranking, jogadorB));

    resultadoTeste("Ranking aceita Carla", inserirResultado(&ranking, jogadorC));

    // Ordena primeiro pelo número de movimentos e depois pelo tempo de resolução.
    
    ordenarPorMovimentosETempo(&ranking);

    Resultado classificacao[MAX_LISTA];

    int quantidade = obterClassificacaoFinal(&ranking, classificacao);

    resultadoTeste("Ranking devolve os 3 resultados", quantidade == 3);

    resultadoTeste("Menor numero de movimentos fica primeiro", quantidade == 3 && classificacao[0].movimentos == 3);

    resultadoTeste("Menor tempo desempata os movimentos", quantidade == 3 && classificacao[0].tempo == 5.0f && classificacao[1].tempo == 20.0f);

    resultadoTeste("Jogador com 4 movimentos fica em terceiro", quantidade == 3 && classificacao[2].movimentos == 4);

    printf("\nClassificacao final de teste:\n");

    for (int i = 0; i < quantidade; i++) {
        printf("%d - %s | %d movimentos | %.0f segundos\n",
            i + 1,
            classificacao[i].nome,
            classificacao[i].movimentos,
            classificacao[i].tempo);
    }

      // RESUMO FINAL

    printf("\n========== RESUMO DOS TESTES ==========\n");
    printf("Testes aprovados: %d\n", testesPassaram);
    printf("Testes com falha: %d\n", testesFalharam);

    return testesFalharam == 0 ? 0 : 1;
}

