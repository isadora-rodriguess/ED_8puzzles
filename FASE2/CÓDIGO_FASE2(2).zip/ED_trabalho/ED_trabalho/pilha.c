#include "pilha.h"
 
/* Cria a pilha vazia: topo = -1 indica que não há nenhum elemento. */
void pilha_inicializar(Pilha *p) {
    p->topo = -1;
}
 
/* Retorna 1 se a pilha não tem nenhum movimento. */
int pilha_vazia(const Pilha *p) {
    return p->topo == -1;
}
 
/* Retorna 1 se a pilha chegou à capacidade máxima. */
int pilha_cheia(const Pilha *p) {
    return p->topo == MAX_PILHA - 1;
}
 
/* Coloca o movimento no topo da pilha.
   Retorna 1 se empilhou e 0 se a pilha estava cheia. */
int pilha_empilhar(Pilha *p, Movimento movimento) {
    if (pilha_cheia(p)) {
        return 0;
    }
 
    p->topo++;                       
    p->dados[p->topo] = movimento;
 
    return 1;
}
 
/* Retira o movimento do topo e o copia para *movimento.
 Retorna 1 se retirou e 0 se a pilha estava vazia. */

int pilha_desempilhar(Pilha *p, Movimento *movimento) {
    if (pilha_vazia(p)) {
        return 0;
    }
 
    *movimento = p->dados[p->topo];  // lê antes de decrementar o topo
    p->topo--;
 
    return 1;
}
 
/* Copia o movimento do topo para *movimento sem retirá-lo da pilha.
   Retorna 1 se havia movimento e 0 se a pilha estava vazia. */
int pilha_topo(const Pilha *p, Movimento *movimento) {
    if (pilha_vazia(p)) {
        return 0;
    }
 
    *movimento = p->dados[p->topo];
 
    return 1;
}