#ifndef RANKING_H
#define RANKING_H
 
#include "lista.h"   // Lista e Resultado
#include "jogo.h"    // Jogador (usado em inserirResultado)
 
/* Este arquivo .h é separado do lista.h para não criar dependência circular com o
   jogo.h. A implementação das funções está no lista.c. */
 
/* Classificação dos jogadores: guarda os resultados em uma Lista. */
typedef struct {
    Lista resultados;
} Ranking;
 
void inicializarRanking(Ranking *rank);
int inserirResultado(Ranking *rank, Jogador jog);
void ordenarPorMovimentosETempo(Ranking *rank);
int obterClassificacaoFinal(const Ranking *rank, Resultado saida[]);
 
#endif