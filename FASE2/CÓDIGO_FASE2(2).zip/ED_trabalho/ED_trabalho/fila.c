#include "fila.h"

/* Inicializa a fila vazia: inicio, fim e quantidade começam em 0. */
 
void fila_inicializar(Fila *f) {
    f->inicio = 0;
    f->fim = 0;
    f->quantidade = 0;
}
 
/* Retorna 1 se a fila não tem nenhum estado, e 0 caso contrário. */
int fila_vazia(const Fila *f) {
    return f->quantidade == 0;
}

/* Retorna 1 se a fila chegou à capacidade máxima (MAX_FILA), e 0 caso contrário. */
 
int fila_cheia(const Fila *f) {
    return f->quantidade == MAX_FILA;
}

/* Insere um estado no fim da fila e incrementa a quantidade.
   Retorna 1 se inseriu e 0 se a fila estava cheia. */
 
int fila_enfileirar(Fila *f, EstadoBusca estado) {
    if (fila_cheia(f)) {
        return 0;
    }
 
    f->estados[f->fim] = estado;
    f->fim = (f->fim + 1) % MAX_FILA;
    f->quantidade++;
 
    return 1;
}

/* Remove o estado da frente da fila, copia esse estado para *estado e decrementa a quantidade.
   Retorna 1 se removeu e 0 se a fila estava vazia. */
 
int fila_desenfileirar(Fila *f, EstadoBusca *estado) {
    if (fila_vazia(f)) {
        return 0;
    }
 
    *estado = f->estados[f->inicio];
    f->inicio = (f->inicio + 1) % MAX_FILA;
    f->quantidade--;
 
    return 1;
}