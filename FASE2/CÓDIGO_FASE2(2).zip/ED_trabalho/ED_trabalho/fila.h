#ifndef FILA_H
#define FILA_H
 
#include "tabuleiro.h"
 
#define MAX_FILA 181440 
/* Capacidade da fila: metade das 9! permutações possíveis, que é o número de
   estados solucionáveis do 8-Puzzle. Como o solver marca cada estado como visitado,
    nenhum estado entra na fila duas vezes, então ela nunca passa desse limite. */

/* Estado explorado pela busca em largura (BFS). */
typedef struct {
    Tabuleiro tabuleiro; // configuração do tabuleiro nesse ponto da busca
    int movimentos;      // jogadas feitas desde a configuração inicial até aqui
} EstadoBusca;
 
typedef struct {
    EstadoBusca estados[MAX_FILA]; // vetor onde os estados ficam guardados
    int inicio;                    // índice do estado da frente (o próximo a sair)
    int fim;                       // índice da posição livre onde entra o próximo
    int quantidade;                // quantos estados estão na fila agora
} Fila;

/*funções que serão implementadas no arquivo .c da fila*/
 
void fila_inicializar(Fila *f);
int fila_vazia(const Fila *f);
int fila_cheia(const Fila *f);
int fila_enfileirar(Fila *f, EstadoBusca estado);
int fila_desenfileirar(Fila *f, EstadoBusca *estado);
 
#endif
