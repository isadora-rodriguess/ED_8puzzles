#ifndef TABULEIRO_H
#define TABULEIRO_H

#define TAM 3

typedef struct {
    int linha;
    int coluna;
} Posicao;


typedef struct {
    int celulas[TAM][TAM];
} Tabuleiro;

typedef struct {
    int peca;
    Posicao origem;
    Posicao destino;
} Movimento;

void inicializar(Tabuleiro *tab, const int configuracao[TAM][TAM]);

int pecaEhAdjacenteAoVazio(const Tabuleiro *tab, Posicao pos);

int moverPeca(Tabuleiro *tab, Posicao pos);

int estaResolvido(const Tabuleiro *tab);
Tabuleiro obterEstadoAtual(const Tabuleiro *tab);

Posicao encontrarVazio(const Tabuleiro *tab);
int tabuleirosIguais(const Tabuleiro *a, const Tabuleiro *b);

int configuracaoEhSolucionavel(const int configuracao[TAM][TAM]);

void imprimirTabuleiro(const Tabuleiro *tab);

#endif
