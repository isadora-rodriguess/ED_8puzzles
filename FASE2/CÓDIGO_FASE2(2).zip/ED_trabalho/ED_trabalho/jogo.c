#include <string.h>
#include "jogo.h"
 
 
/* Implementação do TAD Jogador */
 
/* Cria um jogador zerado: sem nome, sem movimentos e com o cronômetro parado. */
Jogador inicializar_jogador(void) {
    Jogador jog;
 
    jog.nome[0] = '\0';        // string vazia
    jog.movimentos = 0;        // 0 movimentos feitos
    jog.inicio_cronometro = 0; // cronômetro zerado
    jog.fim_cronometro = 0;    // cronômetro zerado
 
    return jog;
}
 
/* Copia o nome recebido para o jogador. */
void definirNome(Jogador *jog, const char *nome) {
    strncpy(jog->nome, nome, TAM_NOME - 1);
    jog->nome[TAM_NOME - 1] = '\0';
}
 
/* Soma 1 ao contador de movimentos do jogador. */
void incrementarMovimentos(Jogador *jog) {
    jog->movimentos++;
}
 
/* Registra o instante de início da partida. Zera o fim para que o cronômetro
   possa ser reiniciado sem ficar com o tempo da partida anterior. */
void iniciarCronometro(Jogador *jog) {
    jog->inicio_cronometro = time(NULL);
    jog->fim_cronometro = 0;
}
 
/* Registra o instante em que a partida terminou. */
void pararCronometro(Jogador *jog) {
    jog->fim_cronometro = time(NULL);
}
 
/* Devolve quantos movimentos o jogador fez. */
int obterMovimentos(const Jogador *jog) {
    return jog->movimentos;
}
 
/* Devolve o tempo decorrido em segundos. O calculo é a diferença entre o fim e o início. */
double obterTempoDecorrido(const Jogador *jog) {
    if (jog->fim_cronometro == 0) {
        return difftime(time(NULL), jog->inicio_cronometro);
    }
 
    return difftime(jog->fim_cronometro, jog->inicio_cronometro);
}
 
 
/*  Implementação do TAD Partida */
 
/* Prepara uma nova partida: guarda a configuração inicial, começa o tabuleiro
   atual igual a ela, zera o histórico de movimentos e marca como em andamento.*/

void iniciarPartida(Partida *part, Tabuleiro configuracaoInicial) {
    part->configuracaoInicial = configuracaoInicial;
    part->tabuleiroAtual = configuracaoInicial;
    pilha_inicializar(&part->historico);
    part->status = 1;
    part->benchmark = 0;
}
 
/* Move a peça indicada em mov.origem, se for válido, e guarda o movimento
   no histórico (origem = onde a peça estava, destino = onde foi parar).
   Retorna 1 se moveu e 0 se foi recusado. */

int registrarMovimentoDoJogador(Partida *part, Jogador *jog, Movimento mov) {
 
    // recusa se a partida acabou ou se não cabe mais nada no histórico
    if (part->status != 1 || pilha_cheia(&part->historico))
        return 0;
    // só pode mover peça adjacente ao espaço vazio (também confere os limites)
    if (!pecaEhAdjacenteAoVazio(&part->tabuleiroAtual, mov.origem))
        return 0;
 
    // monta o registro antes de mover, pois depois o vazio já mudou de lugar
    Movimento feito;
    feito.origem  = mov.origem;
    feito.destino = encontrarVazio(&part->tabuleiroAtual);
    feito.peca    = part->tabuleiroAtual.celulas[mov.origem.linha][mov.origem.coluna];
 
    if (!moverPeca(&part->tabuleiroAtual, mov.origem))
        return 0;
 
    pilha_empilhar(&part->historico, feito);   // guarda para o Undo
    incrementarMovimentos(jog);                // movimento válido conta
 
    // se o tabuleiro ficou resolvido, a partida termina aqui
    if (estaResolvido(&part->tabuleiroAtual)) {
        pararCronometro(jog);
        part->status = 0;
    }
    return 1;
}
 
/* Desfaz o último movimento (Undo). Suguindo a lógica LIFO da pilha. 
O Undo conta como movimento, por isso o contador incrementa.
   Retorna 1 se desfez e 0 se não havia o que desfazer ou a partida acabou. */
int desfazerMovimento(Partida *part, Jogador *jog) {
    Movimento ultimo;
    if (part->status != 1 || !pilha_topo(&part->historico, &ultimo))
        return 0;
 
    // a peça está em destino e o vazio em origem: mover a peça de destino
    // para o vazio a coloca de volta onde estava
    if (!moverPeca(&part->tabuleiroAtual, ultimo.destino)){
        return 0;
    }
    pilha_desempilhar(&part->historico, &ultimo);
    incrementarMovimentos(jog);
    return 1;
    
}
 
/* Retorna 1 se o tabuleiro atual está resolvido. */

int verificarVitoria(const Partida *part) {
    return estaResolvido(&part->tabuleiroAtual);
}
 
/* Guarda o número mínimo de movimentos calculado pela BFS (módulo solver). */
void definirBenchmark(Partida *part, int valor) {
    part->benchmark = valor;
}
 
/* Devolve o benchmark guardado na partida. */
int obterBenchmark(const Partida *part) {
    return part->benchmark;
}
 
/* Marca a partida como encerrada */
void encerrarPartida(Partida *part) {
    part->status = 0;
}