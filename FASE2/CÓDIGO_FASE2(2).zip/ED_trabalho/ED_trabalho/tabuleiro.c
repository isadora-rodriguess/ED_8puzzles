
#include <stdio.h>
#include <stdlib.h>
#include "tabuleiro.h"


static const int CONFIGURACAO_FINAL[TAM][TAM] = {
    {1, 2, 3},
    {4, 5, 6},
    {7, 8, 0}
};


static int posicaoValida(Posicao pos) { // Verificamos a validade da posição para restringir o acesso a posições fora da matriz
    return pos.linha >= 0 && pos.linha < TAM && pos.coluna >= 0 && pos.coluna < TAM;
}

void inicializar(Tabuleiro *tab, const int configuracao[TAM][TAM]) {
    for (int l = 0; l < TAM; l++)
        for (int c = 0; c < TAM; c++)
            tab->celulas[l][c] = configuracao[l][c];
}

Posicao encontrarVazio(const Tabuleiro *tab) { // Identifica a posição do espaço vazio do tabuleiro
    Posicao vazio = {-1, -1};

    for (int l = 0; l < TAM; l++)
        for (int c = 0; c < TAM; c++)
            if (tab->celulas[l][c] == 0) {
                vazio.linha = l;
                vazio.coluna = c;
            }

    return vazio;
}

int pecaEhAdjacenteAoVazio(const Tabuleiro *tab, Posicao pos) {
    if (!posicaoValida(pos))
        return 0;

    Posicao vazio = encontrarVazio(tab);

    return abs(pos.linha - vazio.linha) + abs(pos.coluna - vazio.coluna) == 1;
}

int moverPeca(Tabuleiro *tab, Posicao pos) {
    if (!pecaEhAdjacenteAoVazio(tab, pos))
        return 0;

    Posicao vazio = encontrarVazio(tab);

    tab->celulas[vazio.linha][vazio.coluna] = tab->celulas[pos.linha][pos.coluna];
    tab->celulas[pos.linha][pos.coluna] = 0;

    return 1;
}

int estaResolvido(const Tabuleiro *tab) {
    for (int l = 0; l < TAM; l++)
        for (int c = 0; c < TAM; c++)
            if (tab->celulas[l][c] != CONFIGURACAO_FINAL[l][c])
                return 0;

    return 1;
}

Tabuleiro obterEstadoAtual(const Tabuleiro *tab) {
    return *tab;
}

int tabuleirosIguais(const Tabuleiro *a, const Tabuleiro *b) {
    // Compara duas configurações, será útil para verificar se um movimento ou uma operação de desfazer (undo) restaurou o estado esperado.
    for (int l = 0; l < TAM; l++)
        for (int c = 0; c < TAM; c++)
            if (a->celulas[l][c] != b->celulas[l][c])
                return 0;

    return 1;
}

int configuracaoEhSolucionavel(const int configuracao[TAM][TAM]) { // Verifica se a configuração atual é solucionável, assim evitamos entregar uma configuração inicial para o jogador que não tenha solução.
    int seq[TAM * TAM];
    int vista[TAM * TAM] = {0};
    int n = 0;

    for (int l = 0; l < TAM; l++)
        for (int c = 0; c < TAM; c++) {
            int v = configuracao[l][c];

            if (v < 0 || v >= TAM * TAM || vista[v])
                return 0;

            vista[v] = 1;

            if (v != 0)
                seq[n++] = v;
        }

    int inversoes = 0;

    for (int i = 0; i < n; i++)
        for (int j = i + 1; j < n; j++)
            if (seq[i] > seq[j])
                inversoes++;

    return inversoes % 2 == 0;
}

void imprimirTabuleiro(const Tabuleiro *tab) {
    for (int l = 0; l < TAM; l++) {
        for (int c = 0; c < TAM; c++) {
            if (tab->celulas[l][c] == 0)
                printf(" _");
            else
                printf(" %d", tab->celulas[l][c]);
        }

        printf("\n");
    }
}
