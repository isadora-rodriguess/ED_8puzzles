#ifndef JOGO_H
#define JOGO_H
 
#include <time.h>
#include "tabuleiro.h"
#include "pilha.h"
#include "lista.h"   // usado só para a constante TAM_NOME
 
// TAD Jogador 
 
/* Guarda o desempenho de um participante durante a partida. */
typedef struct {
    char nome[TAM_NOME];       // nome do jogador 
    int movimentos;            // jogadas válidas feitas + jogadas desfeitas (Undo)
    time_t inicio_cronometro;  // instante em que a partida começou
    time_t fim_cronometro;     // instante em que terminou
} Jogador;
 
Jogador inicializar_jogador(void);
void definirNome(Jogador *jog, const char *nome);
void incrementarMovimentos(Jogador *jog);
void iniciarCronometro(Jogador *jog);
void pararCronometro(Jogador *jog);
int obterMovimentos(const Jogador *jog);
double obterTempoDecorrido(const Jogador *jog);
 
 
// TAD Partida
 
// Representa uma rodada.
typedef struct {
    Tabuleiro configuracaoInicial; // configuração de partida, igual para todos
    Tabuleiro tabuleiroAtual;      // estado do tabuleiro durante o jogo
    Pilha historico;               // movimentos feitos para que possa ser possível aplicar o undo
    int status;                    // 1 = em andamento, 0 = encerrada
    int benchmark;                 // mínimo de movimentos, calculado pela BFS
} Partida;

// Funções impelentadas no arquivo .c
 
void iniciarPartida(Partida *part, Tabuleiro configuracaoInicial);
int registrarMovimentoDoJogador(Partida *part, Jogador *jog, Movimento mov);
int desfazerMovimento(Partida *part, Jogador *jog);
int verificarVitoria(const Partida *part);
int obterBenchmark(const Partida *part);
void definirBenchmark(Partida *part, int valor);
void encerrarPartida(Partida *part);
 
#endif