#ifndef LISTA_H
#define LISTA_H
 
#define MAX_LISTA 100   // máximo de resultados que a lista guarda
#define TAM_NOME 50     // tamanho máximo do nome (com o '\0')
 
/* Resultado final de um jogador, guardado para o ranking. */
typedef struct {
    char nome[TAM_NOME];
    int movimentos;
    float tempo;        // tempo de resolução, em segundos
} Resultado;
 
typedef struct {
    Resultado vetor[MAX_LISTA];  // resultados, nas posições 0 até n-1
    int quantidade;              // quantos resultados estão guardados
} Lista;
 
Lista lista_inicializar(void);
int lista_cheia(const Lista *l);
int lista_vazia(const Lista *l);
int lista_inserir_fim(Lista *l, Resultado resultado);
int lista_remover(Lista *l, int posicao);
 
#endif